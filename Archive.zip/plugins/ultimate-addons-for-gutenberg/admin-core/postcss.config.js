module.exports = {
  plugins: {
    tailwindcss: {},
    autoprefixer: { grid:true },
  },
}
