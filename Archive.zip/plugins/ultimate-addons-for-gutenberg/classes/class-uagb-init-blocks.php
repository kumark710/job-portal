<?php
/**
 * UAGB Blocks Initializer
 *
 * Enqueue CSS/JS of all the blocks.
 *
 * @since   1.0.0
 * @package UAGB
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * UAGB_Init_Blocks.
 *
 * @package UAGB
 */
class UAGB_Init_Blocks {


	/**
	 * Member Variable
	 *
	 * @var instance
	 */
	private static $instance;

	/**
	 * Member Variable
	 *
	 * @var block activation
	 */
	private $active_blocks;

	/**
	 *  Initiator
	 */
	public static function get_instance() {
		if ( ! isset( self::$instance ) ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	/**
	 * Constructor
	 */
	public function __construct() {

		// Hook: Editor assets.
		add_action( 'enqueue_block_editor_assets', array( $this, 'editor_assets' ) );

		if ( version_compare( get_bloginfo( 'version' ), '5.8', '>=' ) ) {
			add_filter( 'block_categories_all', array( $this, 'register_block_category' ), 999999, 2 );
		} else {
			add_filter( 'block_categories', array( $this, 'register_block_category' ), 999999, 2 );
		}

		add_action( 'wp_ajax_uagb_get_taxonomy', array( $this, 'get_taxonomy' ) );

		add_action( 'wp_ajax_uagb_gf_shortcode', array( $this, 'gf_shortcode' ) );
		add_action( 'wp_ajax_nopriv_uagb_gf_shortcode', array( $this, 'gf_shortcode' ) );

		add_action( 'wp_ajax_uagb_cf7_shortcode', array( $this, 'cf7_shortcode' ) );
		add_action( 'wp_ajax_nopriv_uagb_cf7_shortcode', array( $this, 'cf7_shortcode' ) );

		add_action( 'wp_ajax_uagb_forms_recaptcha', array( $this, 'forms_recaptcha' ) );

		// For Spectra Global Block Styles.
		add_action( 'wp_ajax_uag_global_block_styles', array( $this, 'uag_global_block_styles' ) );
		// For Spectra Global Quick Action Bar.
		add_action( 'wp_ajax_uag_global_sidebar_enabled', array( $this, 'uag_global_sidebar_enabled' ) );
		add_action( 'wp_ajax_uag_global_update_allowed_block', array( $this, 'uag_global_update_allowed_block' ) );

		if ( ! is_admin() ) {
			add_action( 'render_block', array( $this, 'render_block' ), 5, 2 );

			// For Spectra Global Block Styles.
			add_filter( 'render_block', array( $this, 'add_gbs_class' ), 10, 2 );
		}

		if ( current_user_can( 'edit_posts' ) ) {
			add_action( 'wp_ajax_uagb_svg_confirmation', array( $this, 'confirm_svg_upload' ) );
		}

		add_action( 'init', array( $this, 'register_popup_builder' ) );
		add_filter( 'srfm_enable_redirect_activation', '__return_false' );

		add_action( 'wp_ajax_uagb_sureforms', array( $this, 'sureforms_plugin_activator' ) );
		add_action( 'wp_ajax_uagb_surecart', array( $this, 'surecart_plugin_activator' ) );

	}


	/**
	 * Register the Popup Builder CPT.
	 *
	 * @return void
	 *
	 * @since 2.6.0
	 */
	public function register_popup_builder() {
		$supports = array(
			'title',
			'editor',
			'custom-fields',
			'author',
		);

		$labels = array(
			'name'               => _x( 'Popup Builder', 'plural', 'ultimate-addons-for-gutenberg' ),
			'singular_name'      => _x( 'Spectra Popup', 'singular', 'ultimate-addons-for-gutenberg' ),
			'view_item'          => __( 'View Popup', 'ultimate-addons-for-gutenberg' ),
			'add_new'            => __( 'Create Popup', 'ultimate-addons-for-gutenberg' ),
			'add_new_item'       => __( 'Create New Popup', 'ultimate-addons-for-gutenberg' ),
			'edit_item'          => __( 'Edit Popup', 'ultimate-addons-for-gutenberg' ),
			'new_item'           => __( 'New Popup', 'ultimate-addons-for-gutenberg' ),
			'search_items'       => __( 'Search Popups', 'ultimate-addons-for-gutenberg' ),
			'not_found'          => __( 'No Popups Found', 'ultimate-addons-for-gutenberg' ),
			'not_found_in_trash' => __( 'No Popups in Trash', 'ultimate-addons-for-gutenberg' ),
			'all_items'          => __( 'All Popups', 'ultimate-addons-for-gutenberg' ),
			'item_published'     => __( 'Popup Published', 'ultimate-addons-for-gutenberg' ),
			'item_updated'       => __( 'Popup Updated', 'ultimate-addons-for-gutenberg' ),
		);

		$type_args = array(
			'supports'          => $supports,
			'labels'            => $labels,
			'public'            => false,
			'show_in_menu'      => false,
			'show_in_admin_bar' => true,
			'show_ui'           => true,
			'show_in_rest'      => true,
			'template_lock'     => 'all',
			'template'          => array(
				array( 'spectra/popup-builder', array() ),
			),
			'rewrite'           => array(
				'slug'       => 'spectra-popup',
				'with-front' => false,
				'pages'      => false,
			),
			'capabilities'      => array(
				'edit_post'          => 'manage_options',
				'read_post'          => 'manage_options',
				'delete_post'        => 'manage_options',
				'edit_posts'         => 'manage_options',
				'edit_others_posts'  => 'manage_options',
				'publish_posts'      => 'manage_options',
				'read_private_posts' => 'manage_options',
				'delete_posts'       => 'manage_options',
				'create_posts'       => 'manage_options',
			),
		);

		$meta_args_popup_type = array(
			'single'        => true,
			'type'          => 'string',
			'default'       => 'unset',
			'auth_callback' => '__return_true',
			'show_in_rest'  => true,
		);

		$meta_args_popup_enabled = array(
			'single'        => true,
			'type'          => 'boolean',
			'default'       => false,
			'auth_callback' => '__return_true',
			'show_in_rest'  => true,
		);

		$meta_args_popup_repetition = array(
			'single'        => true,
			'type'          => 'number',
			'default'       => 1,
			'auth_callback' => '__return_true',
			'show_in_rest'  => true,
		);

		register_post_type( 'spectra-popup', $type_args );

		register_post_meta( 'spectra-popup', 'spectra-popup-type', $meta_args_popup_type );
		register_post_meta( 'spectra-popup', 'spectra-popup-enabled', $meta_args_popup_enabled );
		register_post_meta( 'spectra-popup', 'spectra-popup-repetition', $meta_args_popup_repetition );
		do_action( 'register_spectra_pro_popup_meta' );

		$spectra_popup_dashboard = UAGB_Popup_Builder::create_for_admin();

		add_action( 'admin_enqueue_scripts', array( $spectra_popup_dashboard, 'popup_toggle_scripts' ) );
		add_action( 'wp_ajax_uag_update_popup_status', array( $spectra_popup_dashboard, 'update_popup_status' ) );

		do_action( 'spectra_pro_popup_dashboard' );

		add_filter( 'manage_spectra-popup_posts_columns', array( $spectra_popup_dashboard, 'popup_builder_admin_headings' ) );
		add_action( 'manage_spectra-popup_posts_custom_column', array( $spectra_popup_dashboard, 'popup_builder_admin_content' ), 10, 2 );
	}

	/**
	 * Render block.
	 *
	 * @param mixed $block_content The block content.
	 * @param array $block The block data.
	 * @since 1.21.0
	 * @return mixed Returns the new block content.
	 */
	public function render_block( $block_content, $block ) {
		// Register only UAG blocks.
		if ( ! empty( $block['blockName'] ) && strpos( $block['blockName'], 'uagb/' ) !== false ) {
			// Register block on server-side to support WP Hide blocks feature introduce in WP 6.9.
			$registry = WP_Block_Type_Registry::get_instance();
			// Only register if the block is NOT already registered.
			if ( ! $registry->is_registered( $block['blockName'] ) ) {
				$registry->register( $block['blockName'], $block['attrs'] );
			}
		}

		if ( ! empty( $block['attrs']['UAGDisplayConditions'] ) ) {
			switch ( $block['attrs']['UAGDisplayConditions'] ) {
				case 'userstate':
					$block_content = $this->user_state_visibility( $block['attrs'], $block_content );
					break;

				case 'userRole':
					$block_content = $this->user_role_visibility( $block['attrs'], $block_content );
					break;

				case 'browser':
					$block_content = $this->browser_visibility( $block['attrs'], $block_content );
					break;

				case 'os':
					$block_content = $this->os_visibility( $block['attrs'], $block_content );
					break;
				case 'day':
					$block_content = $this->day_visibility( $block['attrs'], $block_content );
					break;
				default:
					// code...
					break;
			}
		}

		// Check if animations extension is enabled and an animation type is selected.
		if (
			'enabled' === \UAGB_Admin_Helper::get_admin_settings_option( 'uag_enable_animations_extension', 'enabled' ) &&
			! empty( $block['attrs']['UAGAnimationType'] )
		) {

			$attrs                                      = $block['attrs'];
			$attrs['UAGAnimationDoNotApplyToContainer'] = isset( $attrs['UAGAnimationDoNotApplyToContainer'] ) ? $attrs['UAGAnimationDoNotApplyToContainer'] : false;
			$block_positioning                          = ! empty( $attrs['UAGPosition'] ) && is_string( $attrs['UAGPosition'] ) ? $attrs['UAGPosition'] : false;

			// Container-specific animation attributes.
			if ( ! $attrs['UAGAnimationDoNotApplyToContainer'] ) {
				// Defaults aren't received here, hence we set them.
				// Without these defaults, empty data is sent to markup (which doesn't affect the functionality at all but still it's a good practice to follow).
				$attrs['UAGAnimationTime']   = isset( $attrs['UAGAnimationTime'] ) ? $attrs['UAGAnimationTime'] : 400;
				$attrs['UAGAnimationDelay']  = isset( $attrs['UAGAnimationDelay'] ) ? $attrs['UAGAnimationDelay'] : 0;
				$attrs['UAGAnimationEasing'] = isset( $attrs['UAGAnimationEasing'] ) ? $attrs['UAGAnimationEasing'] : 'ease';
				$attrs['UAGAnimationRepeat'] = isset( $attrs['UAGAnimationRepeat'] ) ? 'false' : 'true';

				// Container-specific animation attributes.
				$attrs['UAGAnimationDelayInterval'] = isset( $attrs['UAGAnimationDelayInterval'] ) ? $attrs['UAGAnimationDelayInterval'] : 200;

				// If this is a sticky element, don't update the attributes of this element just yet.
				if ( 'sticky' !== $block_positioning ) {
					$aos_attributes = '<div data-aos= "' . esc_attr( $attrs['UAGAnimationType'] ) . '" data-aos-duration="' . esc_attr( $attrs['UAGAnimationTime'] ) . '" data-aos-delay="' . esc_attr( $attrs['UAGAnimationDelay'] ) . '" data-aos-easing="' . esc_attr( $attrs['UAGAnimationEasing'] ) . '" data-aos-once="' . esc_attr( $attrs['UAGAnimationRepeat'] ) . '" ';
					$block_content  = preg_replace( '/<div /', $aos_attributes, $block_content, 1 );
				}
			}
		}

		// Render Block Manipulation for the required Spectra Blocks.
		$block_content = apply_filters( 'uagb_render_block', $block_content, $block );

		// Render Block Manipulation for the required Spectra Pro Blocks.
		$block_content = apply_filters( 'spectra_pro_render_block', $block_content, $block );

		return $block_content;
	}

	/**
	 * User State Visibility.
	 *
	 * @param array $block_attributes The block data.
	 * @param mixed $block_content The block content.
	 *
	 * @since 1.21.0
	 * @return mixed Returns the new block content.
	 */
	public function user_role_visibility( $block_attributes, $block_content ) {
		if ( empty( $block_attributes['UAGUserRole'] ) ) {
			return $block_content;
		}

		$user = wp_get_current_user();
		return is_user_logged_in() && ! empty( $user->roles ) && in_array( $block_attributes['UAGUserRole'], $user->roles, true ) ? '' : $block_content;
	}

	/**
	 * User State Visibility.
	 *
	 * @param array $block_attributes The block data.
	 * @param mixed $block_content The block content.
	 * @since 1.21.0
	 * @return mixed Returns the new block content.
	 */
	public function os_visibility( $block_attributes, $block_content ) {

		if ( empty( $block_attributes['UAGSystem'] ) ) {
			return $block_content;
		}

		$os = array(
			'iphone'   => '(iPhone)',
			'android'  => '(Android)',
			'windows'  => 'Win16|(Windows 95)|(Win95)|(Windows_95)|(Windows 98)|(Win98)|(Windows NT 5.0)|(Windows 2000)|(Windows NT 5.1)|(Windows XP)|(Windows NT 5.2)|(Windows NT 6.0)|(Windows Vista)|(Windows NT 6.1)|(Windows 7)|(Windows NT 4.0)|(WinNT4.0)|(WinNT)|(Windows NT)|Windows ME',
			'open_bsd' => 'OpenBSD',
			'sun_os'   => 'SunOS',
			'linux'    => '(Linux)|(X11)',
			'mac_os'   => '(Mac_PowerPC)|(Macintosh)',
		);

		$user_agent = isset( $_SERVER['HTTP_USER_AGENT'] ) ? sanitize_text_field( $_SERVER['HTTP_USER_AGENT'] ) : '';

		return isset( $os[ $block_attributes['UAGSystem'] ] ) && preg_match( '@' . $os[ $block_attributes['UAGSystem'] ] . '@', $user_agent ) ? '' : $block_content;
	}

	/**
	 * User State Visibility.
	 *
	 * @param array $block_attributes The block data.
	 * @param mixed $block_content The block content.
	 *
	 * @since 1.21.0
	 * @return mixed Returns the new block content.
	 */
	public function browser_visibility( $block_attributes, $block_content ) {

		if ( empty( $block_attributes['UAGBrowser'] ) ) {
			return $block_content;
		}

		$user_agent = isset( $_SERVER['HTTP_USER_AGENT'] ) ? UAGB_Helper::get_browser_name( sanitize_text_field( $_SERVER['HTTP_USER_AGENT'] ) ) : '';

		return $block_attributes['UAGBrowser'] === $user_agent ? '' : $block_content;
	}

	/**
	 * User State Visibility.
	 *
	 * @param array $block_attributes The block data.
	 * @param mixed $block_content The block content.
	 *
	 * @since 1.21.0
	 * @return mixed Returns the new block content.
	 */
	public function user_state_visibility( $block_attributes, $block_content ) {

		if ( ! empty( $block_attributes['UAGLoggedIn'] ) && is_user_logged_in() ) {
			return '';
		}

		if ( ! empty( $block_attributes['UAGLoggedOut'] ) && ! is_user_logged_in() ) {
			return '';
		}

		return $block_content;

	}

	/**
	 * Day Visibility.
	 *
	 * @param array $block_attributes The block data.
	 * @param mixed $block_content The block content.
	 *
	 * @since 2.1.3
	 * @return mixed Returns the new block content.
	 */
	public function day_visibility( $block_attributes, $block_content ) {

		// If not set restriction.
		if ( empty( $block_attributes['UAGDay'] ) ) {
			return $block_content;
		}

		$current_day = strtolower( current_datetime()->format( 'l' ) );
		// Check in restricted day.
		return ! in_array( $current_day, $block_attributes['UAGDay'] ) ? $block_content : '';

	}

	/**
	 * Ajax call to get Taxonomy List.
	 *
	 * @since 2.0.0
	 */
	public function get_taxonomy() {

		$response_data = array(
			'messsage' => __( 'User is not authenticated!', 'ultimate-addons-for-gutenberg' ),
		);

		if ( ! current_user_can( 'edit_posts' ) ) {
			wp_send_json_error( $response_data );
		}

		check_ajax_referer( 'uagb_ajax_nonce', 'nonce' );

		$post_types = UAGB_Helper::get_post_types();

		$return_array = array();

		foreach ( $post_types as $key => $value ) {
			$post_type = $value['value'];

			$taxonomies = get_object_taxonomies( $post_type, 'objects' );
			$data       = array();

			$get_taxonomy_names = get_post_type_object( $post_type ); // Renaming this variable to follow proper naming convention.
			foreach ( $taxonomies as $tax_slug => $tax ) {
				if ( ! $tax->public || ! $tax->show_ui || ! $tax->show_in_rest ) {
					continue;
				}

				$data[ $tax_slug ] = $tax;

				$terms = get_terms( $tax_slug );

				$related_tax_terms = array();

				if ( ! empty( $terms ) ) {
					foreach ( $terms as $t_index => $t_obj ) {
						$related_tax_terms[] = array(
							'id'            => $t_obj->term_id,
							'name'          => $t_obj->name,
							'count'         => $t_obj->count,
							'link'          => get_term_link( $t_obj->term_id ),
							'singular_name' => $get_taxonomy_names ? $get_taxonomy_names->labels->singular_name : 'Post',
							'plural_name'   => $get_taxonomy_names ? $get_taxonomy_names->labels->name : 'Posts', // Adding this field to use it on the editor.
						);
					}

					$return_array[ $post_type ]['terms'][ $tax_slug ] = $related_tax_terms;
				}

				$newcategoriesList = get_terms(
					$tax_slug,
					array(
						'hide_empty' => true,
						'parent'     => 0,
					)
				);

				$related_tax = array();

				if ( ! empty( $newcategoriesList ) ) {
					foreach ( $newcategoriesList as $t_index => $t_obj ) {
						$child_arg     = array(
							'hide_empty' => true,
							'parent'     => $t_obj->term_id,
						);
						$child_cat     = get_terms( $tax_slug, $child_arg );
						$child_cat_arr = $child_cat ? $child_cat : null;
						$related_tax[] = array(
							'id'            => $t_obj->term_id,
							'name'          => $t_obj->name,
							'count'         => $t_obj->count,
							'link'          => get_term_link( $t_obj->term_id ),
							'singular_name' => $get_taxonomy_names ? $get_taxonomy_names->labels->singular_name : 'Post',
							'plural_name'   => $get_taxonomy_names ? $get_taxonomy_names->labels->name : 'Posts', // Adding this field to use it on the editor.
							'children'      => $child_cat_arr,
						);

					}

					$return_array[ $post_type ]['without_empty_taxonomy'][ $tax_slug ] = $related_tax;

				}

				$newcategoriesList_empty_tax = get_terms(
					$tax_slug,
					array(
						'hide_empty' => false,
						'parent'     => 0,
					)
				);

				$related_tax_empty_tax = array();

				if ( ! empty( $newcategoriesList_empty_tax ) ) {
					foreach ( $newcategoriesList_empty_tax as $t_index => $t_obj ) {
						$child_arg_empty_tax     = array(
							'hide_empty' => false,
							'parent'     => $t_obj->term_id,
						);
						$child_cat_empty_tax     = get_terms( $tax_slug, $child_arg_empty_tax );
						$child_cat_empty_tax_arr = $child_cat_empty_tax ? $child_cat_empty_tax : null;
						$related_tax_empty_tax[] = array(
							'id'            => $t_obj->term_id,
							'name'          => $t_obj->name,
							'count'         => $t_obj->count,
							'link'          => get_term_link( $t_obj->term_id ),
							'singular_name' => $get_taxonomy_names ? $get_taxonomy_names->labels->singular_name : 'Post',
							'plural_name'   => $get_taxonomy_names ? $get_taxonomy_names->labels->name : 'Posts', // Adding this field to use it on the editor.
							'children'      => $child_cat_empty_tax_arr,
						);
					}

					$return_array[ $post_type ]['with_empty_taxonomy'][ $tax_slug ] = $related_tax_empty_tax;

				}
			}
			$return_array[ $post_type ]['taxonomy'] = $data;

		}

		wp_send_json_success( apply_filters( 'uagb_taxonomies_list', $return_array ) );
	}

	/**
	 * Renders the Gravity Form shortcode.
	 *
	 * @since 1.12.0
	 */
	public function gf_shortcode() {

		check_ajax_referer( 'uagb_ajax_nonce', 'nonce' );

		$id = isset( $_POST['formId'] ) ? intval( $_POST['formId'] ) : 0;

		if ( $id && 0 !== $id && -1 !== $id ) {
			$data['html'] = do_shortcode( '[gravityforms id="' . $id . '" ajax="true"]' );
		} else {
			$data['html'] = '<p>' . __( 'Please select a valid Gravity Form.', 'ultimate-addons-for-gutenberg' ) . '</p>';
		}
		wp_send_json_success( $data );
	}

	/**
	 * Renders the forms recaptcha keys.
	 *
	 * @since 2.0.0
	 */
	public function forms_recaptcha() {

		$response_data = array(
			'messsage' => __( 'User is not authenticated!', 'ultimate-addons-for-gutenberg' ),
		);

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( $response_data );
		}

		check_ajax_referer( 'uagb_ajax_nonce', 'nonce' );
		// security validation done in later stage.
		$value = isset( $_POST['value'] ) ? json_decode( wp_unslash( $_POST['value'] ), true ) : array(); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized

		\UAGB_Admin_Helper::update_admin_settings_option( 'uag_recaptcha_secret_key_v2', sanitize_text_field( $value['reCaptchaSecretKeyV2'] ) );
		\UAGB_Admin_Helper::update_admin_settings_option( 'uag_recaptcha_secret_key_v3', sanitize_text_field( $value['reCaptchaSecretKeyV3'] ) );
		\UAGB_Admin_Helper::update_admin_settings_option( 'uag_recaptcha_site_key_v2', sanitize_text_field( $value['reCaptchaSiteKeyV2'] ) );
		\UAGB_Admin_Helper::update_admin_settings_option( 'uag_recaptcha_site_key_v3', sanitize_text_field( $value['reCaptchaSiteKeyV3'] ) );

		$response_data = array(
			'messsage' => __( 'Successfully saved data!', 'ultimate-addons-for-gutenberg' ),
		);
		wp_send_json_success( $response_data );

	}

	/**
	 * Renders the Sure Form.
	 *
	 * @since 2.19.0
	 * @return void
	 */
	public function sureforms_plugin_activator() {
		// Check user capability.
		if ( ! ( current_user_can( 'activate_plugins' ) && current_user_can( 'install_plugins' ) ) ) {
			wp_send_json_error(
				array(
					'success' => false,
					'message' => 'User is not authenticated!',
				) 
			);
		}

		// Verify nonce.
		if ( ! check_ajax_referer( 'uagb_ajax_nonce', 'security', false ) ) {
			wp_send_json_error(
				array(
					'success' => false,
					'message' => 'Invalid nonce.',
				) 
			);
		}

		$installed_plugins   = get_plugins();
		$status_of_sureforms = isset( $installed_plugins['sureforms/sureforms.php'] ) 
			? ( is_plugin_active( 'sureforms/sureforms.php' ) ? 'active' : 'inactive' ) 
			: 'not-installed';

		if ( class_exists( '\BSF_UTM_Analytics\Inc\Utils' ) && is_callable( '\BSF_UTM_Analytics\Inc\Utils::update_referer' ) ) {
			// If the plugin is found and the update_referer function is callable, update the referer with the corresponding product slug.
			\BSF_UTM_Analytics\Inc\Utils::update_referer( 'ultimate-addons-for-gutenberg', 'sureforms' );
		}

		// If plugin is not installed, install it first.
		if ( 'not-installed' === $status_of_sureforms ) {
			include_once ABSPATH . 'wp-admin/includes/class-wp-upgrader.php';
			include_once ABSPATH . 'wp-admin/includes/plugin-install.php';

			$plugin_slug = 'sureforms';
			$plugin_data = plugins_api( 'plugin_information', array( 'slug' => $plugin_slug ) );

			// Check if $plugin_data is valid and contains the download_link property.
			if ( is_wp_error( $plugin_data ) || ! is_object( $plugin_data ) || empty( $plugin_data->download_link ) ) {
				wp_send_json_error(
					array(
						'success' => false,
						'message' => 'Error fetching plugin data.',
					) 
				);
			}

			if ( is_object( $plugin_data ) || is_array( $plugin_data ) ) {
				$download_link = ( is_object( $plugin_data ) && isset( $plugin_data->download_link ) ) ? $plugin_data->download_link : '';
				$skin          = new WP_Ajax_Upgrader_Skin();
				$upgrader      = new Plugin_Upgrader( $skin );
				$installed     = $upgrader->install( $download_link );

				if ( is_wp_error( $installed ) ) {
					wp_send_json_error(
						array(
							'success' => false,
							'message' => 'Failed to install the plugin.',
						) 
					);
				}
			}

			$installed_plugins   = get_plugins();
			$status_of_sureforms = isset( $installed_plugins['sureforms/sureforms.php'] ) ? 'inactive' : 'not-installed';
		}

		// If the plugin is installed but inactive, activate it.
		if ( 'inactive' === $status_of_sureforms ) {
			$activate = activate_plugin( 'sureforms/sureforms.php', '', false, false );

			if ( is_wp_error( $activate ) ) {
				wp_send_json_error(
					array(
						'success' => false,
						'message' => $activate->get_error_message(),
					) 
				);
			}

			wp_send_json_success(
				array(
					'success' => true,
					'message' => 'Plugin successfully activated.',
				) 
			);
		}

		// If already active, send a success message.
		if ( 'active' === $status_of_sureforms ) {
			wp_send_json_success(
				array(
					'success' => true,
					'message' => 'Plugin is already active.',
				) 
			);
		}

		// If no condition matches, send an error response.
		wp_send_json_error(
			array(
				'success' => false,
				'message' => 'Unexpected error occurred.',
			) 
		);
	}

	/**
	 * Renders the Sure Form.
	 *
	 * @since 2.19.0
	 * @return void
	 */
	public function surecart_plugin_activator() {
		// Check user capability.
		if ( ! ( current_user_can( 'activate_plugins' ) && current_user_can( 'install_plugins' ) ) ) {
			wp_send_json_error(
				array(
					'success' => false,
					'message' => 'User is not authenticated!',
				) 
			);
		}

		// Verify nonce.
		if ( ! check_ajax_referer( 'uagb_ajax_nonce', 'security', false ) ) {
			wp_send_json_error(
				array(
					'success' => false,
					'message' => 'Invalid nonce.',
				) 
			);
		}

		$installed_plugins  = get_plugins();
		$status_of_surecart = isset( $installed_plugins['surecart/surecart.php'] ) 
			? ( is_plugin_active( 'surecart/surecart.php' ) ? 'active' : 'inactive' ) 
			: 'not-installed';

		if ( class_exists( '\BSF_UTM_Analytics\Inc\Utils' ) && is_callable( '\BSF_UTM_Analytics\Inc\Utils::update_referer' ) ) {
			// If the plugin is found and the update_referer function is callable, update the referer with the corresponding product slug.
			\BSF_UTM_Analytics\Inc\Utils::update_referer( 'ultimate-addons-for-gutenberg', 'surecart' );
		}

		// If plugin is not installed, install it first.
		if ( 'not-installed' === $status_of_surecart ) {
			include_once ABSPATH . 'wp-admin/includes/class-wp-upgrader.php';
			include_once ABSPATH . 'wp-admin/includes/plugin-install.php';

			$plugin_slug = 'surecart';
			$plugin_data = plugins_api( 'plugin_information', array( 'slug' => $plugin_slug ) );

			if ( is_wp_error( $plugin_data ) || ! is_object( $plugin_data ) || empty( $plugin_data->download_link ) ) {
				wp_send_json_error(
					array(
						'success' => false,
						'message' => 'Error fetching plugin data.',
					) 
				);
			}

			if ( is_object( $plugin_data ) || is_array( $plugin_data ) ) {
				$download_link = ( is_object( $plugin_data ) && isset( $plugin_data->download_link ) ) ? $plugin_data->download_link : '';
				$skin          = new WP_Ajax_Upgrader_Skin();
				$upgrader      = new Plugin_Upgrader( $skin );
				$installed     = $upgrader->install( $download_link );

				if ( is_wp_error( $installed ) ) {
					wp_send_json_error(
						array(
							'success' => false,
							'message' => 'Failed to install the plugin.',
						) 
					);
				}
			}

			$installed_plugins  = get_plugins();
			$status_of_surecart = isset( $installed_plugins['surecart/surecart.php'] ) ? 'inactive' : 'not-installed';
		}

		// If the plugin is installed but inactive, activate it.
		if ( 'inactive' === $status_of_surecart ) {
			$activate = activate_plugin( 'surecart/surecart.php' );
			if ( is_wp_error( $activate ) ) {
				wp_send_json_error(
					array(
						'success' => false,
						'message' => $activate->get_error_message(),
					) 
				);
			}

			wp_send_json_success(
				array(
					'success' => true,
					'message' => 'Plugin successfully activated.',
				) 
			);
		}

		// If already active, send a success message.
		if ( 'active' === $status_of_surecart ) {
			wp_send_json_success(
				array(
					'success' => true,
					'message' => 'Plugin is already active.',
				) 
			);
		}

		// If no condition matches, send an error response.
		wp_send_json_error(
			array(
				'success' => false,
				'message' => 'Unexpected error occurred.',
			) 
		);
	}

	/**
	 * Renders the Contect Form 7 shortcode.
	 *
	 * @since 1.10.0
	 */
	public function cf7_shortcode() {

		check_ajax_referer( 'uagb_ajax_nonce', 'nonce' );

		$id = isset( $_POST['formId'] ) ? intval( $_POST['formId'] ) : 0;

		if ( $id && 0 !== $id && -1 !== $id ) {
			$data['html'] = do_shortcode( '[contact-form-7 id="' . $id . '" ajax="true"]' );
		} else {
			$data['html'] = '<p>' . __( 'Please select a valid Contact Form 7.', 'ultimate-addons-for-gutenberg' ) . '</p>';
		}
		wp_send_json_success( $data );
	}

	/**
	 * Gutenberg block category for UAGB.
	 *
	 * @param array  $categories Block categories.
	 * @param object $post Post object.
	 * @since 1.0.0
	 */
	public function register_block_category( $categories, $post ) {
		$categories = array_merge(
			array(
				array(
					'slug'  => 'uagb',
					'title' => __( 'Spectra', 'ultimate-addons-for-gutenberg' ),
				),
			),
			$categories
		);
		// Define the new category to be added.
		$new_category = array(
			'slug'  => 'extension',
			'title' => __( 'Extensions', 'ultimate-addons-for-gutenberg' ),
			'icon'  => '',
		);

		// Find the index where the new category should be inserted.
		$insert_after_slug = 'spectra-pro'; // Default insertion point.
		$insert_index      = false;

		// Look for the 'spectra-pro' category.
		foreach ( $categories as $index => $category ) {
			if ( $insert_after_slug === $category['slug'] ) {
				$insert_index = $index + 1;
				break;
			}
		}

		// If 'spectra-pro' is not found, look for 'uagb'.
		if ( false === $insert_index ) {
			$insert_after_slug = 'uagb';
			foreach ( $categories as $index => $category ) {
				if ( $insert_after_slug === $category['slug'] ) {
					$insert_index = $index + 1;
					break;
				}
			}
		}

		// If neither is found, append the new category at the end.
		if ( false === $insert_index ) {
			$categories[] = $new_category;
		} else {
			array_splice( $categories, $insert_index, 0, array( $new_category ) );
		}

		return $categories;
	}

	/**
	 * Localize SVG icon scripts in chunks.
	 * Ex - if 1800 icons available so we will localize 4 variables for it.
	 *
	 * @since 2.7.0
	 * @return void
	 */
	public function add_svg_icon_assets() {
		$localize_icon_chunks = UAGB_Helper::backend_load_font_awesome_icons();
		if ( ! $localize_icon_chunks ) {
			return;
		}

		foreach ( $localize_icon_chunks as $chunk_index => $value ) {
			wp_localize_script( 'uagb-block-editor-js', "uagb_svg_icons_{$chunk_index}", $value );
		}
	}

	/**
	 * Get the status of a plugin.
	 * This function is used internally in the editor upsell scripts to check if Spectra Pro is installed or not.
	 *
	 * @since 2.19.2
	 *
	 * @param  string $plugin_init_file Plugin init file.
	 * @return string
	 */
	public static function get_plugin_status( $plugin_init_file ) {

		$installed_plugins = get_plugins();

		if ( ! isset( $installed_plugins[ $plugin_init_file ] ) ) {
			return 'Install';
		} elseif ( is_plugin_active( $plugin_init_file ) ) {
			return 'Activated';
		} else {
			return 'Installed';
		}
	}

	/**
	 * Enqueue essential variables for v3 blocks when full v2 assets are not loaded.
	 *
	 * This method provides only the essential 5 variables that v3 blocks need:
	 * - is_rtl: RTL support detection
	 * - spectra_pro_status: Spectra Pro plugin status
	 * - uagb_url: Ultimate Addons plugin URL
	 * - font_awesome_5_polyfill: Font Awesome polyfill data
	 * - uagb_svg_icons: Font Awesome SVG icon data
	 *
	 * @since 3.0.0
	 *
	 * @return void
	 */
	private function enqueue_minimal_v3_block_assets() {
		// Get all installed plugins to check Spectra Pro status.
		$installed_plugins = get_plugins();
		
		// Determine Spectra Pro plugin status (not-installed, inactive, or active).
		$spectra_pro_status = isset( $installed_plugins['spectra-pro/spectra-pro.php'] ) 
			? ( is_plugin_active( 'spectra-pro/spectra-pro.php' ) 
				? 'active' 
				: 'inactive' ) 
			: 'not-installed';

		// Build array of minimal variables matching exactly what v2 provides.
		$minimal_block_variables = array(
			'is_rtl'                  => is_rtl(), // Check if current site is RTL.
			'spectra_pro_status'      => $spectra_pro_status, // Spectra Pro plugin status.
			'uagb_url'                => UAGB_URL, // Ultimate Addons plugin URL.
			'font_awesome_5_polyfill' => get_spectra_font_awesome_polyfiller(), // Font Awesome 5 polyfill data.
			'current_post_id'         => get_the_ID(), // Current post ID for popup builder close class functionality.
		);

		// Enqueue minimal script for localization.
		wp_enqueue_script(
			'uagb-essential-vars',
			'data:text/javascript;base64,' . base64_encode( '/* Essential Variables */' ),
			array( 'wp-blocks' ),
			UAGB_VER,
			true
		);

		// Get merged SVG icons for v3 compatibility.
		$localize_icon_chunks = UAGB_Helper::backend_load_font_awesome_icons();
		if ( $localize_icon_chunks ) {
			$merged_icons = array();
			foreach ( $localize_icon_chunks as $chunk_index => $value ) {
				if ( is_array( $value ) ) {
					$merged_icons = array_merge( $merged_icons, $value );
				}
			}
			// Add merged icons to minimal variables.
			$minimal_block_variables['uagb_svg_icons'] = $merged_icons;
		}

		// Localize minimal variables using same uagb_blocks_info namespace.
		wp_localize_script( 'uagb-essential-vars', 'uagb_blocks_info', $minimal_block_variables );

		// Add inline JavaScript to process SVG icons exactly like v2.
		$inline_js = '
		if ( uagb_blocks_info.uagb_svg_icons?.uagb_category_list ) {
			wp.uagb_icon_category_list = [ ...uagb_blocks_info.uagb_svg_icons.uagb_category_list ];
			delete uagb_blocks_info.uagb_svg_icons.uagb_category_list;
		}

		wp.UAGBSvgIcons = Object.keys( uagb_blocks_info.uagb_svg_icons );
		';

		wp_add_inline_script( 'uagb-essential-vars', $inline_js, 'after' );
	}

	/**
	 * Enqueue Gutenberg block assets for backend editor.
	 *
	 * @since 1.0.0
	 */
	public function editor_assets() {
		// Check if assets should be excluded for the current post type.
		if ( UAGB_Admin_Helper::should_exclude_assets_for_cpt() ) {
			return; // Early return to prevent loading assets.
		}

		$should_load_full_assets = UAGB_Helper::is_old_user_less_than_v3() || UAGB_Helper::is_v2_blocks_enabled();

		// If not loading full assets, provide minimal assets for v3 blocks.
		if ( ! $should_load_full_assets ) {
			$this->enqueue_minimal_v3_block_assets();
			return;
		}

		$uagb_ajax_nonce = wp_create_nonce( 'uagb_ajax_nonce' );

		$script_dep_path = UAGB_DIR . 'dist/blocks.min.asset.php';
		$script_info     = file_exists( $script_dep_path )
			? include $script_dep_path
			: array(
				'dependencies' => array(),
				'version'      => UAGB_VER,
			);
		global $pagenow;

		$script_dep = array_merge( $script_info['dependencies'], array( 'wp-blocks', 'wp-i18n', 'wp-element', 'wp-components', 'wp-api-fetch' ) );

		if ( 'widgets.php' !== $pagenow ) {
			$script_dep = array_merge( $script_info['dependencies'], array( 'wp-editor' ) );
		}

		$js_ext = ( SCRIPT_DEBUG ) ? '.js' : '.min.js';

		wp_enqueue_code_editor( array( 'type' => 'text/css' ) );
		wp_enqueue_script( 'wp-theme-plugin-editor' );
		wp_enqueue_style( 'wp-codemirror' );

		// Scripts.
		$blocks_script = file_exists( UAGB_DIR . 'dist/blocks.min.js' ) ? 'blocks.min.js' : 'blocks.js';
		wp_enqueue_script(
			'uagb-block-editor-js', // Handle.
			UAGB_URL . 'dist/' . $blocks_script,
			$script_dep, // Dependencies, defined above.
			$script_info['version'], // UAGB_VER.
			true // Enqueue the script in the footer.
		);

		wp_set_script_translations( 'uagb-block-editor-js', 'ultimate-addons-for-gutenberg' );

		// Common Editor style.
		wp_enqueue_style(
			'uagb-block-common-editor-css', // Handle.
			UAGB_URL . 'dist/common-editor.css', // Block editor CSS.
			array( 'wp-edit-blocks' ), // Dependency to include the CSS after it.
			UAGB_VER
		);

		wp_localize_script( 'uagb-block-editor-js', 'uag_react', array( 'pro_plugin_status' => self::get_plugin_status( 'spectra-pro/spectra-pro.php' ) ) );

		wp_enqueue_script( 'uagb-deactivate-block-js', UAGB_URL . 'admin/assets/blocks-deactivate.js', array( 'wp-blocks' ), UAGB_VER, true );

		$blocks       = array();
		$saved_blocks = UAGB_Admin_Helper::get_admin_settings_option( '_uagb_blocks' );

		if ( is_array( $saved_blocks ) ) {
			foreach ( $saved_blocks as $slug => $data ) {

				$_slug       = 'uagb/' . $slug;
				$blocks_info = UAGB_Block_Module::get_blocks_info();

				if ( ! isset( $blocks_info[ $_slug ] ) ) {
					continue;
				}

				$current_block = $blocks_info[ $_slug ];

				if ( isset( $current_block['is_child'] ) && $current_block['is_child'] ) {
					continue;
				}

				if ( isset( $current_block['is_active'] ) && ! $current_block['is_active'] ) {
					continue;
				}

				if ( isset( $saved_blocks[ $slug ] ) ) {
					if ( 'disabled' === $saved_blocks[ $slug ] ) {
						array_push( $blocks, $_slug );
					}
				}
			}
		}

		wp_localize_script(
			'uagb-deactivate-block-js',
			'uagb_deactivate_blocks',
			array(
				'deactivated_blocks' => $blocks,
			)
		);
		$display_condition            = UAGB_Admin_Helper::get_admin_settings_option( 'uag_enable_block_condition', 'enabled' );
		$display_responsive_condition = UAGB_Admin_Helper::get_admin_settings_option( 'uag_enable_block_responsive', 'enabled' );

		$enable_selected_fonts = UAGB_Admin_Helper::get_admin_settings_option( 'uag_load_select_font_globally', 'disabled' );
		$selected_fonts        = array();

		if ( 'enabled' === $enable_selected_fonts ) {

			/**
			 * Selected fonts variable
			 *
			 * @var array
			 */
			$selected_fonts = UAGB_Admin_Helper::get_admin_settings_option( 'uag_select_font_globally', array() );

			if ( ! empty( $selected_fonts ) ) {
				usort(
					$selected_fonts,
					function( $a, $b ) {
						return strcmp( $a['label'], $b['label'] );
					}
				);

				$default_selected = array(
					array(
						'value' => 'Default',
						'label' => __( 'Default', 'ultimate-addons-for-gutenberg' ),
					),
				);
				$selected_fonts   = array_merge( $default_selected, $selected_fonts );
			}
		}

		$uagb_exclude_blocks_from_extension = array( 'core/archives', 'core/calendar', 'core/latest-comments', 'core/tag-cloud', 'core/rss' );
		// Get all registered blocks from WordPress.
		$blocks = WP_Block_Type_Registry::get_instance()->get_all_registered();
		// Filter blocks to get only Spectra and Spectra Pro blocks.
		// This creates an array of block names that start with 'spectra/' or 'spectra-pro/'.
		$spectra_blocks = array_filter(
			array_keys( $blocks ),
			function( $name ) {
				return str_starts_with( $name, 'spectra/' ) || str_starts_with( $name, 'spectra-pro/' );
			}
		);
		// Merge the core excluded blocks with Spectra blocks.
		// This ensures both core blocks and Spectra blocks are excluded from extensions.
		$uagb_exclude_blocks_from_extension = array_merge( $uagb_exclude_blocks_from_extension, $spectra_blocks );

		$content_width = \UAGB_Admin_Helper::get_global_content_width();


		$container_padding = UAGB_Admin_Helper::get_admin_settings_option( 'uag_container_global_padding', 'default' );

		if ( 'default' === $container_padding ) {
			\UAGB_Admin_Helper::update_admin_settings_option( 'uag_container_global_padding', 10 );
			$container_padding = 10;
		}

		$container_elements_gap = UAGB_Admin_Helper::get_admin_settings_option( 'uag_container_global_elements_gap', 20 );
		$screen                 = get_current_screen();

		$uag_enable_quick_action_sidebar = apply_filters( 'uag_enable_quick_action_sidebar', UAGB_Admin_Helper::get_admin_settings_option( 'uag_enable_quick_action_sidebar', 'enabled' ) );

		// An array of all the required Spectra Admin URLs.
		$spectra_admin_urls = array(
			'settings' => array(
				'editor_enhancements' => admin_url( 'admin.php?page=spectra&path=settings&settings=editor-enhancements' ),
			),
		);

		$inherit_from_theme               = 'deleted' !== UAGB_Admin_Helper::get_admin_settings_option( 'uag_btn_inherit_from_theme_fallback', 'deleted' ) ? 'disabled' : UAGB_Admin_Helper::get_admin_settings_option( 'uag_btn_inherit_from_theme', 'disabled' );
		$astra_theme_settings_available   = defined( 'ASTRA_THEME_SETTINGS' );
		$astra_theme_body_text_decoration = $astra_theme_settings_available && function_exists( 'astra_get_font_extras' ) && function_exists( 'astra_get_option' ) ? astra_get_font_extras( astra_get_option( 'body-font-extras' ), 'text-decoration' ) : '';
		$installed_plugins                = get_plugins();
		$status                           = isset( $installed_plugins['spectra-pro/spectra-pro.php'] ) 
					? ( is_plugin_active( 'spectra-pro/spectra-pro.php' ) 
						? 'active' 
						: 'inactive' ) 
					: 'not-installed';
		$status_of_surecart               = isset( $installed_plugins['surecart/surecart.php'] ) 
					? ( is_plugin_active( 'surecart/surecart.php' ) 
						? 'active' 
						: 'inactive' ) 
					: 'not-installed';
		$status_of_sureforms              = isset( $installed_plugins['sureforms/sureforms.php'] ) 
					? ( is_plugin_active( 'sureforms/sureforms.php' ) 
						? 'active' 
						: 'inactive' ) 
					: 'not-installed';

		$localized_params = array(
			'cf7_is_active'                           => class_exists( 'WPCF7_ContactForm' ),
			'gf_is_active'                            => class_exists( 'GFForms' ),
			'category'                                => 'uagb',
			'premium_category'                        => 'extension',
			'ajax_url'                                => admin_url( 'admin-ajax.php' ),
			'spectra_admin_urls'                      => $spectra_admin_urls,
			'cf7_forms'                               => $this->get_cf7_forms(),
			'gf_forms'                                => $this->get_gravity_forms(),
			'tablet_breakpoint'                       => UAGB_TABLET_BREAKPOINT,
			'mobile_breakpoint'                       => UAGB_MOBILE_BREAKPOINT,
			'image_sizes'                             => UAGB_Helper::get_image_sizes(),
			'post_types'                              => UAGB_Helper::get_post_types(),
			'uagb_ajax_nonce'                         => $uagb_ajax_nonce,
			'uagb_svg_confirmation_nonce'             => current_user_can( 'edit_posts' ) ? wp_create_nonce( 'uagb_confirm_svg_nonce' ) : '',
			'svg_confirmation'                        => current_user_can( 'edit_posts' ) ? get_option( 'spectra_svg_confirmation' ) : '',
			'uagb_home_url'                           => home_url(),
			'user_role'                               => $this->get_user_role(),
			'uagb_url'                                => UAGB_URL,
			'uagb_mime_type'                          => UAGB_Helper::get_mime_type(),
			'uagb_site_url'                           => UAGB_URI,
			'enableConditions'                        => apply_filters_deprecated( 'enable_block_condition', array( $display_condition ), '1.23.4', 'uag_enable_block_condition' ),
			'enableConditionsForCoreBlocks'           => apply_filters( 'enable_block_condition_for_core', true ),
			'enableResponsiveConditionsForCoreBlocks' => apply_filters( 'enable_responsive_condition_for_core', true ),
			'enableMasonryGallery'                    => apply_filters( 'uag_enable_masonry_gallery', UAGB_Admin_Helper::get_admin_settings_option( 'uag_enable_masonry_gallery', 'enabled' ) ),
			'enableQuickActionSidebar'                => $uag_enable_quick_action_sidebar,
			'enableAnimationsExtension'               => apply_filters( 'uag_enable_animations_extension', UAGB_Admin_Helper::get_admin_settings_option( 'uag_enable_animations_extension', 'enabled' ) ),
			'enableResponsiveConditions'              => apply_filters( 'enable_block_responsive', UAGB_Admin_Helper::get_admin_settings_option( 'uag_enable_block_responsive', 'enabled' ) ),
			'number_of_icon_chunks'                   => UAGB_Helper::$number_of_icon_chunks,
			'uagb_enable_extensions_for_blocks'       => apply_filters( 'uagb_enable_extensions_for_blocks', array() ),
			'uagb_exclude_blocks_from_extension'      => $uagb_exclude_blocks_from_extension,
			'uag_load_select_font_globally'           => $enable_selected_fonts,
			'uag_select_font_globally'                => $selected_fonts,
			'uagb_old_user_less_than_2'               => get_option( 'uagb-old-user-less-than-2' ),
			'collapse_panels'                         => UAGB_Admin_Helper::get_admin_settings_option( 'uag_collapse_panels', 'enabled' ),
			'copy_paste'                              => UAGB_Admin_Helper::get_admin_settings_option( 'uag_copy_paste', 'enabled' ),
			'enable_on_page_css_button'               => UAGB_Admin_Helper::get_admin_settings_option( 'uag_enable_on_page_css_button', 'yes' ),
			'content_width'                           => $content_width,
			'container_global_padding'                => $container_padding,
			'container_elements_gap'                  => $container_elements_gap,
			'recaptcha_site_key_v2'                   => UAGB_Admin_Helper::get_admin_settings_option( 'uag_recaptcha_site_key_v2', '' ),
			'recaptcha_site_key_v3'                   => UAGB_Admin_Helper::get_admin_settings_option( 'uag_recaptcha_site_key_v3', '' ),
			'recaptcha_secret_key_v2'                 => UAGB_Admin_Helper::get_admin_settings_option( 'uag_recaptcha_secret_key_v2', '' ),
			'recaptcha_secret_key_v3'                 => UAGB_Admin_Helper::get_admin_settings_option( 'uag_recaptcha_secret_key_v3', '' ),
			'blocks_editor_spacing'                   => apply_filters( 'uagb_default_blocks_editor_spacing', UAGB_Admin_Helper::get_admin_settings_option( 'uag_blocks_editor_spacing', 0 ) ),
			'load_font_awesome_5'                     => UAGB_Admin_Helper::get_admin_settings_option( 'uag_load_font_awesome_5' ),
			'auto_block_recovery'                     => UAGB_Admin_Helper::get_admin_settings_option( 'uag_auto_block_recovery' ),
			'font_awesome_5_polyfill'                 => array(),
			'spectra_custom_fonts'                    => apply_filters( 'spectra_system_fonts', array() ),
			'spectra_pro_status'                      => $status,
			'spectra_custom_css_example'              => __(
				'Use custom class added in block\'s advanced settings to target your desired block. Examples:
		.my-class {text-align: center;} // my-class is a custom selector',
				'ultimate-addons-for-gutenberg'
			),
			'is_rtl'                                  => is_rtl(),
			'insta_linked_accounts'                   => UAGB_Admin_Helper::get_admin_settings_option( 'uag_insta_linked_accounts', array() ),
			'insta_all_users_media'                   => apply_filters( 'uag_instagram_transients', array() ),
			'is_site_editor'                          => $screen->id,
			'current_post_id'                         => get_the_ID(),
			'btn_inherit_from_theme'                  => UAGB_Admin_Helper::get_admin_settings_option( 'uag_btn_inherit_from_theme', 'disabled' ),
			'btn_inherit_from_theme_fallback'         => $inherit_from_theme,
			'wp_version'                              => get_bloginfo( 'version' ),
			'is_block_theme'                          => UAGB_Admin_Helper::is_block_theme(),
			'is_customize_preview'                    => is_customize_preview(),
			'uag_enable_gbs_extension'                => \UAGB_Admin_Helper::get_admin_settings_option( 'uag_enable_gbs_extension', 'enabled' ),
			'current_theme'                           => wp_get_theme()->get( 'Name' ),
			'is_gutenberg_activated'                  => is_plugin_active( 'gutenberg/gutenberg.php' ), // TODO: Once Gutenberg merged the rename functionality code in WP then we need to remove localization part for is_gutenberg_activated.
			'header_titlebar_status'                  => UAGB_Admin_Helper::get_admin_settings_option( 'uag_enable_header_titlebar', 'enabled' ),
			'is_astra_based_theme'                    => $astra_theme_settings_available,
			'astra_body_text_decoration'              => $astra_theme_body_text_decoration,
			// creating an array of iframe names to ignore and checking against that array.
			// Add more iframe names to ignore, this is done by using the 'spectra_exclude_crops_iframes' filter.
			'exclude_crops_iframes'                   => apply_filters( 'spectra_exclude_crops_iframes', array( '__privateStripeMetricsController8690' ) ),
			'status_of_sureforms'                     => $status_of_sureforms,
			'status_of_surecart'                      => $status_of_surecart,
			'docsUrl'                                 => \UAGB_Admin_Helper::get_spectra_pro_url( '/docs/', 'free-plugin', 'uagb-editor-page', 'uagb-plugin' ),
			'upsellModalEditor'                       => \UAGB_Admin_Helper::get_spectra_pro_url( '/pricing/', 'free-plugin', 'spectra-editor', 'upsell-popup-view-plan' ),
			'contry_code'                             => \UAGB_Admin_Helper::get_user_country_code(),
			'enable_v2_blocks'                        => get_option( 'register-v2-blocks' ),
			'is_user_less_than_3'                     => get_option( 'uagb-old-user-less-than-3' ),
		);

		wp_localize_script(
			'uagb-block-editor-js',
			'uagb_blocks_info',
			$localized_params
		);

		// Enqueue the assets for editor upsells.
		wp_enqueue_style(
			'spectra-upsell-banner-tailwind-style',
			UAGB_URL . 'dist/blocks.css',
			array(),
			UAGB_VER
		);

		// To match the editor with frontend.
		// Scripts Dependency.
		UAGB_Scripts_Utils::enqueue_blocks_dependency_both();
		// Style.
		UAGB_Scripts_Utils::enqueue_blocks_styles();
		// RTL Styles.
		UAGB_Scripts_Utils::enqueue_blocks_rtl_styles();

		// Add svg icons in chunks.
		$this->add_svg_icon_assets();
	}

	/**
	 *  Get the User Roles
	 *
	 *  @since 1.21.0
	 */
	public function get_user_role() {

		global $wp_roles;

		$field_options = array();

		$role_lists = $wp_roles->get_names();

		$field_options[0] = array(
			'value' => '',
			'label' => __( 'None', 'ultimate-addons-for-gutenberg' ),
		);

		foreach ( $role_lists as $key => $role_list ) {
			$field_options[] = array(
				'value' => $key,
				'label' => $role_list,
			);
		}

		return $field_options;
	}

	/**
	 * Function to integrate CF7 Forms.
	 *
	 * @since 1.10.0
	 */
	public function get_cf7_forms() {
		$field_options = array();

		if ( class_exists( 'WPCF7_ContactForm' ) ) {
			$args             = array(
				'post_type'      => 'wpcf7_contact_form',
				'posts_per_page' => -1,
			);
			$forms            = get_posts( $args );
			$field_options[0] = array(
				'value' => -1,
				'label' => __( 'Select Form', 'ultimate-addons-for-gutenberg' ),
			);
			if ( $forms ) {
				foreach ( $forms as $form ) {
					$field_options[] = array(
						'value' => $form->ID,
						'label' => $form->post_title,
					);
				}
			}
		}

		if ( empty( $field_options ) ) {
			$field_options = array(
				'-1' => __( 'You have not added any Contact Form 7 yet.', 'ultimate-addons-for-gutenberg' ),
			);
		}
		return $field_options;
	}

	/**
	 * Returns all gravity forms with ids
	 *
	 * @since 1.12.0
	 * @return array Key Value paired array.
	 */
	public function get_gravity_forms() {
		$field_options = array();

		if ( class_exists( 'GFForms' ) ) {
			$forms            = RGFormsModel::get_forms( null, 'title' );
			$field_options[0] = array(
				'value' => -1,
				'label' => __( 'Select Form', 'ultimate-addons-for-gutenberg' ),
			);
			if ( is_array( $forms ) ) {
				foreach ( $forms as $form ) {
					$field_options[] = array(
						'value' => $form->id,
						'label' => $form->title,
					);
				}
			}
		}

		if ( empty( $field_options ) ) {
			$field_options = array(
				'-1' => __( 'You have not added any Gravity Forms yet.', 'ultimate-addons-for-gutenberg' ),
			);
		}

		return $field_options;
	}

	/**
	 * Ajax call to confirm add users confirmation option in database
	 *
	 * @return void
	 * @since 2.4.0
	 */
	public function confirm_svg_upload() {
		check_ajax_referer( 'uagb_confirm_svg_nonce', 'svg_nonce' );
		if ( empty( $_POST['confirmation'] ) || 'yes' !== sanitize_text_field( $_POST['confirmation'] ) ) {
			wp_send_json_error( array( 'message' => __( 'Invalid request', 'ultimate-addons-for-gutenberg' ) ) );
		}

		update_option( 'spectra_svg_confirmation', 'yes' );
		wp_send_json_success();
	}

	/**
	 * Add Global Block Styles Class.
	 *
	 * @param string $block_content The block content.
	 * @param array  $block The block data.
	 * @since 2.9.0
	 * @return mixed Returns the new block content.
	 */
	public function add_gbs_class( $block_content, $block ) {
		if ( empty( $block['blockName'] ) || ! is_string( $block['blockName'] ) || false === strpos( $block['blockName'], 'uagb/' ) || empty( $block['attrs']['globalBlockStyleId'] ) || empty( $block['attrs']['block_id'] ) ) {
			return $block_content;
		}

		// Check if GBS is enabled.
		$gbs_status = \UAGB_Admin_Helper::get_admin_settings_option( 'uag_enable_gbs_extension', 'enabled' );

		$style_name       = $block['attrs']['globalBlockStyleId'];
		$style_class_name = 'spectra-gbs-' . $style_name;

		// If GBS extension is disabled then add static class name.
		if ( 'disabled' === $gbs_status ) {
			$_block_slug      = str_replace( 'uagb/', '', $block['blockName'] );
			$class_name       = 'spectra-gbs-uagb-gbs-default-' . $_block_slug;
			$style_class_name = $class_name;
		}

		$block_id = 'uagb-block-' . $block['attrs']['block_id'];

		// Replace the block id with the block id and the style class name.
		$replacement_string = esc_attr( $block_id ) . ' ' . esc_attr( $style_class_name );
		$html               = str_replace( $block_id, $replacement_string, $block_content );

		return $html;
	}

	/**
	 * Function to save enable/disable data.
	 *
	 * @since 2.12.0
	 * @return void
	 */
	public function uag_global_sidebar_enabled() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error();
		}

		if ( ! check_ajax_referer( 'uagb_ajax_nonce', 'security', false ) ) {
			wp_send_json_error();
		}

		if ( ! empty( $_POST['enableQuickActionSidebar'] ) ) {
			$spectra_enable_quick_action_sidebar = ( 'enabled' === $_POST['enableQuickActionSidebar'] ? 'enabled' : 'disabled' );
			\UAGB_Admin_Helper::update_admin_settings_option( 'uag_enable_quick_action_sidebar', $spectra_enable_quick_action_sidebar );
			wp_send_json_success();
		}
		wp_send_json_error();
	}

	/**
	 * Function to save allowed block data.
	 *
	 * @since 2.12.0
	 * @return void
	 */
	public function uag_global_update_allowed_block() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error();
		}

		if ( ! check_ajax_referer( 'uagb_ajax_nonce', 'security', false ) ) {
			wp_send_json_error();
		}

		if ( ! empty( $_POST['defaultAllowedQuickSidebarBlocks'] ) ) {
			$spectra_default_allowed_quick_sidebar_blocks = json_decode( wp_unslash( sanitize_text_field( $_POST['defaultAllowedQuickSidebarBlocks'] ) ), true );
			\UAGB_Admin_Helper::update_admin_settings_option( 'uagb_quick_sidebar_allowed_blocks', $spectra_default_allowed_quick_sidebar_blocks );
			wp_send_json_success();
		}
		wp_send_json_error();
	}

	/**
	 * Function to save Spectra Global Block Styles data.
	 *
	 * @since 2.9.0
	 * @return void
	 */
	public function uag_global_block_styles() {
		// Check if gbs enabled or not.
		if ( 'enabled' !== \UAGB_Admin_Helper::get_admin_settings_option( 'uag_enable_gbs_extension', 'enabled' ) ) {
			wp_send_json_error();
		}


		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error();
		}

		if ( ! check_ajax_referer( 'uagb_ajax_nonce', 'security', false ) ) {
			wp_send_json_error();
		}

		$response_data = array( 'messsage' => __( 'No post data found!', 'ultimate-addons-for-gutenberg' ) );

		if ( empty( $_POST['spectraGlobalStyles'] ) ) {
			wp_send_json_error( $response_data );
		}

		$global_block_styles = json_decode( wp_unslash( sanitize_text_field( $_POST['spectraGlobalStyles'] ) ), true );

		if ( ! empty( $_POST['bulkUpdateStyles'] ) && 'no' !== $_POST['bulkUpdateStyles'] ) {
			update_option( 'spectra_global_block_styles', $global_block_styles );
			wp_send_json_success( $global_block_styles );
		}

		if ( empty( $_POST ) || empty( $_POST['attributes'] ) || empty( $_POST['blockName'] ) || empty( $_POST['postId'] ) || empty( $_POST['spectraGlobalStyles'] ) || ! is_array( $global_block_styles ) ) {
			wp_send_json_error( $response_data );
		}

		$global_block_styles = is_array( $global_block_styles ) ? $global_block_styles : array();
		$block_attr          = array();

		$post_id = sanitize_text_field( $_POST['postId'] );
		// Not sanitizing this array because $_POST['attributes'] is a very large array of different types of attributes.
		foreach ( $global_block_styles as $key => $style ) {
			if ( ! empty( $_POST['globalBlockStyleId'] ) && ! empty( $style['value'] ) && $style['value'] === $_POST['globalBlockStyleId'] ) {
				$block_attr = $style['attributes'];

				if ( ! $block_attr ) {
					wp_send_json_error( $response_data );
					break;
				}

				$_block_slug = str_replace( 'uagb/', '', sanitize_text_field( $_POST['blockName'] ) );
				$_block_css  = UAGB_Block_Module::get_frontend_css( $_block_slug, $block_attr, $block_attr['block_id'], true );

				$desktop = '';
				$tablet  = '';
				$mobile  = '';

				$tab_styling_css = '';
				$mob_styling_css = '';
				$desktop        .= $_block_css['desktop'];
				$tablet         .= $_block_css['tablet'];
				$mobile         .= $_block_css['mobile'];
				if ( ! empty( $tablet ) ) {
					$tab_styling_css .= '@media only screen and (max-width: ' . UAGB_TABLET_BREAKPOINT . 'px) {';
					$tab_styling_css .= $tablet;
					$tab_styling_css .= '}';
				}

				if ( ! empty( $mobile ) ) {
					$mob_styling_css .= '@media only screen and (max-width: ' . UAGB_MOBILE_BREAKPOINT . 'px) {';
					$mob_styling_css .= $mobile;
					$mob_styling_css .= '}';
				}
				$_block_css                                    = $desktop . $tab_styling_css . $mob_styling_css;
				$global_block_styles[ $key ]['frontendStyles'] = $_block_css;
				$gbs_stored                                    = get_option( 'spectra_global_block_styles', array() );
				$gbs_stored_key_value                          = is_array( $gbs_stored ) && isset( $gbs_stored[ $key ] ) ? $gbs_stored[ $key ] : array();

				if ( ! empty( $gbs_stored_key_value['post_ids'] ) ) {
					$global_block_styles[ $key ]['post_ids'] = array_merge( $global_block_styles[ $key ]['post_ids'], $gbs_stored_key_value['post_ids'] );
				}

				// For FSE template slug.
				if ( ! empty( $gbs_stored_key_value['page_template_slugs'] ) ) {
					$global_block_styles[ $key ]['page_template_slugs'] = array_merge( $global_block_styles[ $key ]['page_template_slugs'], $gbs_stored_key_value['page_template_slugs'] );
				}

				// For global styles (  widget and customize area ).
				if ( ! empty( $gbs_stored_key_value['styleForGlobal'] ) ) {
					$global_block_styles[ $key ]['styleForGlobal'] = array_merge( $global_block_styles[ $key ]['styleForGlobal'], $gbs_stored_key_value['styleForGlobal'] );
				}

				update_option( 'spectra_global_block_styles', $global_block_styles );

				if ( ! empty( $global_block_styles[ $key ]['post_ids'] ) && is_array( $global_block_styles[ $key ]['post_ids'] ) ) {
					foreach ( $global_block_styles[ $key ]['post_ids'] as $post_id ) {
						UAGB_Helper::delete_page_assets( $post_id );
					}
				}
			}
		}

		$spectra_gbs_google_fonts = get_option( 'spectra_gbs_google_fonts', array() );

		// Global Font Families.
		$font_families = array();
		foreach ( $block_attr as $name => $attribute ) {
			if ( false !== strpos( $name, 'Family' ) && '' !== $attribute ) {

				$font_families[] = $attribute;
			}
		}

		if ( isset( $block_attr['globalBlockStyleId'] ) && is_array( $spectra_gbs_google_fonts ) ) {
			$spectra_gbs_google_fonts[ $block_attr['globalBlockStyleId'] ] = $font_families;
			if ( isset( $spectra_gbs_google_fonts[ $block_attr['globalBlockStyleId'] ] ) && is_array( $spectra_gbs_google_fonts[ $block_attr['globalBlockStyleId'] ] ) ) {
				$spectra_gbs_google_fonts[ $block_attr['globalBlockStyleId'] ] = array_unique( $spectra_gbs_google_fonts[ $block_attr['globalBlockStyleId'] ] );
			}
		}

		update_option( 'spectra_gbs_google_fonts', $spectra_gbs_google_fonts );

		if ( ! empty( $_POST['globalBlockStylesFontFamilies'] ) ) {
			$spectra_gbs_google_fonts_editor = json_decode( wp_unslash( sanitize_text_field( $_POST['globalBlockStylesFontFamilies'] ) ), true );
			update_option( 'spectra_gbs_google_fonts_editor', $spectra_gbs_google_fonts_editor );
		}

		wp_send_json_success( $global_block_styles );
	}
}

/**
 *  Prepare if class 'UAGB_Init_Blocks' exist.
 *  Kicking this off by calling 'get_instance()' method
 */
UAGB_Init_Blocks::get_instance();
