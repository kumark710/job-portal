<?php
/*
Plugin Name: Job Portal System
Description: Final Year Job Portal Project
Version: 1.0
Author: Rohit Kumar
*/

if (!defined('ABSPATH')) exit;

/* ===============================
   ADMIN MENU
================================ */

add_action('admin_menu', function () {

    add_menu_page(
        'Job Portal',
        'Job Portal',
        'manage_options',
        'job-portal',
        'jps_admin_page',
        'dashicons-portfolio'
    );

    add_submenu_page(
        'job-portal',
        'Applications',
        'Applications',
        'manage_options',
        'job-applications',
        'jps_show_applications'
    );
});


/* ===============================
   ADMIN JOB POST FORM
================================ */

function jps_admin_page() {
    ?>
    <div class="wrap">
        <h1>Add Job</h1>

        <form method="post">
            <input type="text" name="job_title" placeholder="Job Title" required><br><br>
            <input type="text" name="company_name" placeholder="Company" required><br><br>
            <input type="text" name="location" placeholder="Location" required><br><br>
            <textarea name="description" placeholder="Job Description" required></textarea><br><br>
            <input type="submit" name="submit_job" class="button button-primary" value="Post Job">
        </form>
    </div>
    <?php
}


/* ===============================
   SAVE JOB
================================ */

if (isset($_POST['submit_job'])) {
    global $wpdb;

    $wpdb->insert(
        $wpdb->prefix . 'job_portal_jobs',
        [
            'job_title' => sanitize_text_field($_POST['job_title']),
            'company_name' => sanitize_text_field($_POST['company_name']),
            'location' => sanitize_text_field($_POST['location']),
            'description' => sanitize_textarea_field($_POST['description'])
        ]
    );
}


/* ===============================
   FRONTEND JOB LIST
================================ */

add_shortcode('job_list', function () {
    global $wpdb;
    $jobs = $wpdb->get_results("SELECT * FROM {$wpdb->prefix}job_portal_jobs ORDER BY id DESC");

    if (!$jobs) return "<p>No jobs available.</p>";

    ob_start();

    foreach ($jobs as $job) { ?>
        <div class="job-card">
            <h3><?php echo $job->job_title; ?></h3>
            <p><strong>Company:</strong> <?php echo $job->company_name; ?></p>
            <p><strong>Location:</strong> <?php echo $job->location; ?></p>
            <p><?php echo $job->description; ?></p>

            <form method="post" enctype="multipart/form-data">
                <input type="hidden" name="job_id" value="<?php echo $job->id; ?>">
                <input type="text" name="name" placeholder="Your Name" required>
                <input type="email" name="email" placeholder="Your Email" required>
                <input type="file" name="resume" required>
                <button type="submit" name="apply_job">Apply</button>
            </form>
        </div>
    <?php }

    return ob_get_clean();
});


/* ===============================
   SAVE APPLICATION
================================ */

if (isset($_POST['apply_job'])) {
    global $wpdb;

    $upload = wp_upload_dir();
    $file = time() . "_" . $_FILES['resume']['name'];
    move_uploaded_file($_FILES['resume']['tmp_name'], $upload['path'] . "/" . $file);

    $wpdb->insert(
        $wpdb->prefix . 'job_applications',
        [
            'job_id' => $_POST['job_id'],
            'name' => sanitize_text_field($_POST['name']),
            'email' => sanitize_email($_POST['email']),
            'resume' => $file
        ]
    );
}


/* ===============================
   VIEW APPLICATIONS (ADMIN)
================================ */

function jps_show_applications() {
    global $wpdb;
    $apps = $wpdb->get_results("SELECT * FROM {$wpdb->prefix}job_applications");

    echo "<div class='wrap'><h1>Applications</h1>";

    echo "<table class='widefat'>
        <tr>
            <th>ID</th>
            <th>Job ID</th>
            <th>Name</th>
            <th>Email</th>
            <th>Resume</th>
        </tr>";

    foreach ($apps as $a) {
        echo "<tr>
            <td>$a->id</td>
            <td>$a->job_id</td>
            <td>$a->name</td>
            <td>$a->email</td>
            <td><a href='".wp_upload_dir()['baseurl']."/$a->resume' target='_blank'>View</a></td>
        </tr>";
    }

    echo "</table></div>";
}


/* ===============================
   STYLING
================================ */

add_action('wp_head', function () { ?>
    <style>
    
    body {
        background: #f5f7fb;
        font-family: 'Segoe UI', sans-serif;
    }
    
    .job-card {
        background: #ffffff;
        border-radius: 12px;
        padding: 25px;
        margin-bottom: 25px;
        box-shadow: 0 10px 25px rgba(0,0,0,0.06);
        transition: 0.3s;
    }
    
    .job-card:hover {
        transform: translateY(-5px);
    }
    
    .job-card h3 {
        color: #1f2937;
        font-size: 22px;
    }
    
    .job-card p {
        color: #4b5563;
        margin: 6px 0;
    }
    
    .job-card input,
    .job-card button {
        width: 100%;
        padding: 12px;
        margin-top: 10px;
        border-radius: 6px;
        border: 1px solid #ddd;
    }
    
    .job-card button {
        background: linear-gradient(135deg, #2563eb, #1e40af);
        color: white;
        border: none;
        font-weight: bold;
        cursor: pointer;
    }
    
    .job-card button:hover {
        background: #1e3a8a;
    }
    
    </style>
    <?php });
    